
#!/bin/bash
# dual_qtc_qubic.sh — одновременно скачивает (если нужно) и запускает onezerominer и qubminer

set -e

# 1) Пути для установки
ONEZO_DIR="/hive/miners/onezerominer"
ONEZO_URL="https://github.com/OneZeroMiner/onezerominer/releases/download/v1.4.8/onezerominer-1.4.8.tar.gz"
QUBIC_DIR="/hive/miners/qubminer"
QUBIC_URL="https://github.com/qubic-li/hiveos/releases/download/latest/qubminer-latest.tar.gz"

# 2) Установка onezerominer, если нет
if [ ! -x "${ONEZO_DIR}/onezerominer" ]; then
  echo ">> Installing onezerominer..."
  rm -rf "${ONEZO_DIR}" \
    && mkdir -p "${ONEZO_DIR}" \
    && wget -qO- "${ONEZO_URL}" | tar -xz -C "${ONEZO_DIR}"
fi

# 3) Установка qubminer, если нет
if [ ! -x "${QUBIC_DIR}/qubminer" ]; then
  echo ">> Installing qubminer..."
  rm -rf "${QUBIC_DIR}" \
    && mkdir -p "${QUBIC_DIR}" \
    && wget -qO- "${QUBIC_URL}" | tar -xz -C "${QUBIC_DIR}"
fi

# 4) Переменные окружения (GPU-опции, если нужны для onezerominer)
export GPU_FORCE_64BIT_PTR=0
export GPU_MAX_ALLOC_PERCENT=100
export GPU_USE_SYNC_OBJECTS=1

# 5) Запуск onezerominer (Qtc) в фоне
"${ONEZO_DIR}/onezerominer" -a qhash \
    -o qubitcoin.luckypool.io:8611 \
    -u %WAL%.%WORKER_NAME% \
    &

# Пауза для инициализации
sleep 5

# 6) Запуск qubminer (Qubic) в фоне
"${QUBIC_DIR}/qubminer" \
    --url wss://wps.qubic.li/ws \
    --accessToken="eyJhbGc..." \
    --cpuOnly \
    --amountOfThreads 28 \
    --randomx-1gb-pages \
    --pps \
    --xmr \
    &

# 7) Ждём обоих процессов, чтобы HiveOS не считал майнер «упавшим»
wait